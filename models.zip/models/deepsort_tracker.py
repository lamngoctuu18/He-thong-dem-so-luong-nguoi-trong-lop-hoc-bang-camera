from deep_sort_realtime.deepsort_tracker import DeepSort

tracker = DeepSort()
