from ultralytics import YOLO

yolo_model = YOLO('yolov8l.pt')
